# Retrospectiva – Sprint 1 (Estrella de Mar)

## ⭐ Comenzar a hacer
- Dividir mejor las tareas grandes en subtareas más pequeñas.
- Documentar decisiones de diseño en el README.

## ➕ Hacer más
- Buscar inspiración visual en sitios reales.
- Tomar notas durante el desarrollo para la retro.

## ➡️ Continuar haciendo
- Planificación antes de escribir código.
- Uso de wireframes para definir estructura.

## ➖ Hacer menos
- Cambios de diseño sobre la marcha sin validación.

## ❌ Dejar de hacer
- Subir archivos ZIP en lugar de carpetas estructuradas.